Project Title: Virtual Mouse


Video Demo: https://www.youtube.com/watch?v=acLQQbpwScU


Usage: pip install requirements.txt


Objective: 
The main goal of the proposed AI virtual mouse system is to create a replacement for the conventional mouse system that can perform and control mouse functions. This can be done with the aid of a web camera that records hand gestures and hand tips and then processes these frames to perform the specific mouse function, such as the left click and movement of cursor. 


Algorithms used:

Mediapipe:
A framework called MediaPipe is a Google open-source framework that is applied in a machine learning pipeline. Since the MediaPipe framework was created utilising time series data, it can be used for cross-platform programming. The MediaPipe architecture supports multiple audio and video formats since it is multimodal. The MediaPipe framework is used by the developer to create and analyse systems using graphs as well as to create systems for application-related purposes. The pipeline configuration is where the actions in the MediaPipe-using system are carried out.

Real-time detection and identification of a hand or palm is accomplished using a single-shot detector model. The MediaPipe uses the single-shot detector model. Because it is simpler to learn palms, the hand detection module initially trains a model for palm detection. Additionally, the nonmaximum suppression greatly outperforms the maximum suppression on small objects like the palms or fists. 

OpenCV:
OpenCV is a computer vision library which contains image-processing algorithms for object detection. OpenCV is a library of python programming language, and real-time computer vision applications can be developed by using the computer vision library. The OpenCV library is used in image and video processing and also analysis such as face detection and object detection.


Methodology:

Step 1: The Camera Used in the AI Virtual Mouse System
The webcam frames from a laptop or PC serve as the foundation for the proposed AI virtual mouse system. The web camera will begin recording video after the video capture object is created using the Python computer vision package OpenCV. The virtual AI system receives frames from the web camera and processes them. 

Step 2: Capturing the Video and Processing
The webcam is used by the AI virtual mouse system to capture each frame till the programme is finished.
As illustrated in the accompanying code, the video frames are converted from BGR to RGB in order to find the hands in the video frame by frame. 
def findHands(self, img, draw = True):
    imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    self.results = self.hands.process(imgRGB)

Step 3: (Virtual Screen Matching) Rectangular Region for Moving through the Window
The transformational method is used by the AI virtual mouse system to transfer the fingertip coordinates from the webcam screen to the computer window full screen for mouse operation. A rectangular box is drawn in relation to the computer window in the webcam region when the hands are detected, and we move the mouse cursor around the window as necessary once we determine which finger is capable of executing the precise mouse operation. 

Step 4: For the Mouse Cursor Moving around the Computer Window
If the index finger is up with tip Id = 1 or both the index finger with tip Id = 1 and the middle finger with tip Id = 2 are up, the mouse cursor is made to move around the window of the computer using the AutoPy package of Python

Step 5: For the Mouse to Perform Left Button Click
If both the index finger with tip Id = 1 and the thumb finger with tip Id = 0 are up and the distance between the two fingers is lesser than 30px, the computer is made to perform the left mouse button click using the same Python package.
